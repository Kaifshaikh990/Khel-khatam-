export * from "./details-header";
