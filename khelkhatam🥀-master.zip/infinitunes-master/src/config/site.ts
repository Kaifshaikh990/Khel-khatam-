export const siteConfig = {
  name: "Khel Khatam🥀",
  url: "https://availity.vercel.app",
  description:
    "A Simple Music Player Web App built using Next.js, shadcn/ui, TailwindCSS, DrizzleORM and more...",

  author: {
    name: "ATMKBFJG",
    url: "nahi bataunga",
    email: "Behen Ka Rishta Bhejega?",
    x: "Toxicity Pasand Nahi",
  },

  links: {
    github: "Github use bhi karne aata hai tujhe?",
    discord: "Nahi Use Karta",
    x: "Toxicity Pasand Nahi",
  },
};

export type SiteConfig = typeof siteConfig;
